package edu.br.appnotas;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Button;

import edu.br.appnotas.bo.ItemBo;
import edu.br.appnotas.model.Item;

public class MainActivity extends AppCompatActivity {
private EditText nt1, nt2;
private TextView res1;
private Button btn1, btn2;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        nt1=(EditText)findViewById(R.id.nt1);
        nt2=(EditText)findViewById(R.id.nt2);
        res1=(TextView) findViewById(R.id.res1);
        btn1=(Button)findViewById((R.id.btn1));
        btn2=(Button)findViewById((R.id.btn2));

btn1.setOnClickListener(new View.OnClickListener() {
    @Override
    public void onClick(View v) {
res1.setText(String.valueOf(new ItemBo(new Item(Double.parseDouble(nt1.getText().toString()),
        Double.parseDouble(nt2.getText().toString() ) )).CalcularNota() ) );

    }
});
btn2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Bundle args=new Bundle();
 args.putSerializable("item", new Item (Double.parseDouble(nt1.getText().toString()),
         Double.parseDouble(nt2.getText().toString() ) ));
 Intent intent=new Intent(MainActivity.this, MainActivity2.class);
 intent.putExtra("item", args );
 startActivity(intent);

            }
        });
  }


}