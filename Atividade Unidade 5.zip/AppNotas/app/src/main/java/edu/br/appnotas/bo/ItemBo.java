package edu.br.appnotas.bo;
import edu.br.appnotas.model.Item;

public class ItemBo {
private Item item;

    public ItemBo(Item item) {
        this.item = item;
    }
    public  double CalcularNota(){
        return (this.item.getNota1() + this.item.getNota2())/2;
    }


}
 