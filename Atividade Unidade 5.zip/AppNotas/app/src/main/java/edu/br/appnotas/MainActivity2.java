package edu.br.appnotas;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import edu.br.appnotas.bo.ItemBo;
import edu.br.appnotas.model.Item;

public class MainActivity2 extends AppCompatActivity {
    private EditText nt1, nt2;
    private TextView res1;
    private Button btn1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        nt1=(EditText)findViewById(R.id.sub1);
        nt2=(EditText)findViewById(R.id.sub2);
        res1=(TextView) findViewById(R.id.res2);
        btn1=(Button)findViewById((R.id.btn3));
Bundle args=getIntent().getBundleExtra("item");

Item item=(Item)args.getSerializable("item");
nt1.setText( String.valueOf(item.getNota1()));
nt2.setText( String.valueOf(item.getNota2()));
        btn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                res1.setText(String.valueOf(new ItemBo(new Item(Double.parseDouble(nt1.getText().toString()),
                        Double.parseDouble(nt2.getText().toString() ) )).CalcularNota() ) );
                if(args==null);
                finish();
            }
    });
}

}